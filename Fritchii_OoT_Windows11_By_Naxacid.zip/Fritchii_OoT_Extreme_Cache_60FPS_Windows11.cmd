:: Fritchii OoT - adaptive Windows 11 performance installer/launcher
:: Put this CMD in the emulator folder. The game stays in .\Spel\
@echo off
setlocal EnableExtensions
title Fritchii - Ocarina of Time performance setup
set "FRITCHII_SELF=%~f0"
set "FRITCHII_INSTALLDIR=%~dp0"
set "FRITCHII_PS=%TEMP%\Fritchii-OoT-%RANDOM%-%RANDOM%.ps1"

echo ================================================================
echo  FRITCHII - OCARINA OF TIME - COMPLETE SETUP
echo  Extracting embedded installer...
echo ================================================================
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ErrorActionPreference='Stop'; $raw=[IO.File]::ReadAllText($env:FRITCHII_SELF); $i=$raw.LastIndexOf('#PSSTART'); if($i -lt 0){throw 'Embedded PowerShell payload marker is missing.'}; $tail=$raw.Substring($i+8); $j=$tail.LastIndexOf('#PSEND'); if($j -lt 0){throw 'Embedded PowerShell end marker is missing.'}; $body=$tail.Substring(0,$j).TrimStart([char]13,[char]10); if($body -notmatch 'function Write-Log'){throw 'Installer payload is incomplete.'}; Set-Content -LiteralPath $env:FRITCHII_PS -Value $body -Encoding UTF8"
if errorlevel 1 (
  echo.
  echo ERROR: Could not extract the installer payload.
  pause
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%FRITCHII_PS%" %*
set "RC=%ERRORLEVEL%"

if exist "%FRITCHII_PS%" del "%FRITCHII_PS%" >nul 2>&1
echo.
if "%RC%"=="0" (
  echo Setup finished. See the report and log in the Fritchii setup folder under your user profile.
) else (
  echo Setup stopped with exit code %RC%. Read the error above and the log.
)
echo.
pause
exit /b %RC%

#PSSTART
#Requires -Version 5.1
<#
.SYNOPSIS
  Portable installation of the latest official Fritchii release for The Legend of Zelda: Ocarina of Time.
  Windows 11 x64. Paths resolve relative to this CMD file.

.PARAMETER DryRun      Shows all planned actions without making changes.
.PARAMETER Force       Continue even if the emulator is already running.
.PARAMETER Revert      Restores the configuration backup and Windows changes.
#>
[CmdletBinding()]
param(
    [string]$InstallDir = '',
    [string]$GameFile = '',
    [switch]$DryRun,
    [switch]$Force,
    [switch]$Revert,
    [string]$ElevatedPayloadBase64 = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
if ($ElevatedPayloadBase64) {
    $elevatedPayload = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($ElevatedPayloadBase64)) | ConvertFrom-Json
    if ($elevatedPayload.InstallDir) { $InstallDir = [string]$elevatedPayload.InstallDir }
    if ($elevatedPayload.GameFile) { $GameFile = [string]$elevatedPayload.GameFile }
    $DryRun = [bool]$elevatedPayload.DryRun
    $Force = [bool]$elevatedPayload.Force
    $Revert = [bool]$elevatedPayload.Revert
}
$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
$isAdministrator = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdministrator -and -not $DryRun) {
    $restartPayload = [ordered]@{ InstallDir=$InstallDir; GameFile=$GameFile; DryRun=[bool]$DryRun; Force=[bool]$Force; Revert=[bool]$Revert } | ConvertTo-Json -Compress
    $restartEncoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($restartPayload))
    $restartArgs = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -ElevatedPayloadBase64 ' + $restartEncoded
    try {
        $elevatedProcess = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $restartArgs -Verb RunAs -Wait -PassThru
        exit ([int]$elevatedProcess.ExitCode)
    } catch {
        Write-Host "Administrator approval is required to create and activate the permanent Windows power plan: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if ([string]::IsNullOrWhiteSpace($InstallDir)) {
    $InstallDir = $env:FRITCHII_INSTALLDIR
}
if (-not $PSBoundParameters.ContainsKey('InstallDir') -and -not [string]::IsNullOrWhiteSpace($InstallDir) -and
    -not (Test-Path -LiteralPath (Join-Path $InstallDir 'lichii.exe') -PathType Leaf)) {
    # If this CMD was launched from the desktop, reuse the existing Fritchii
    # desktop link to find its install folder instead of installing onto Desktop.
    $desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Fritchii.lnk'
    if (Test-Path -LiteralPath $desktopShortcut -PathType Leaf) {
        try {
            $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($desktopShortcut)
            $linkedExe = [string]$shortcut.TargetPath
            if ([IO.Path]::GetFileName($linkedExe) -ieq 'lichii.exe' -and (Test-Path -LiteralPath $linkedExe -PathType Leaf)) {
                $InstallDir = Split-Path -Parent $linkedExe
            } elseif ([IO.Path]::GetFileName($linkedExe) -match '(?i)^powershell(?:\.exe)?$' -and
                [string]$shortcut.Arguments -match '(?i)-File\s+"([^"]*Fritchii-Performance-Launcher\.ps1)"') {
                $linkedLauncher = $Matches[1]
                if (Test-Path -LiteralPath $linkedLauncher -PathType Leaf) { $InstallDir = Split-Path -Parent $linkedLauncher }
            }
        } catch { }
    }
}
if ([string]::IsNullOrWhiteSpace($InstallDir)) {
    throw 'InstallDir is missing. Place this CMD file in the emulator root folder.'
}
$InstallDir = [IO.Path]::GetFullPath($InstallDir.Trim().TrimEnd('\'))
if ([string]::IsNullOrWhiteSpace($GameFile)) {
    $gameFolder = Join-Path $InstallDir 'Spel'
    $candidates = @()
    if (Test-Path -LiteralPath $gameFolder -PathType Container) {
        $candidates = @(Get-ChildItem -LiteralPath $gameFolder -Filter '*.nup' -File -Recurse -ErrorAction SilentlyContinue)
    }
    # Prefer this game's Title ID, then the highest version number embedded in the filename.
    $ootCandidates = @($candidates | Where-Object { $_.Name -match '(?i)(0400486024DEC000|Ocarina.*of.*Time)' })
    if ($ootCandidates.Count -gt 0) { $candidates = $ootCandidates }
    elseif ($candidates.Count -gt 1) { throw 'Multiple NUP files were found in Spel, but none could be identified as Ocarina of Time. Move other games elsewhere or specify -GameFile.' }
    if ($candidates.Count -gt 0) {
        $ranked = foreach ($f in $candidates) {
            $ver = 0L
            if ($f.Name -match '(?i)\[v(\d+)\]') { [void][long]::TryParse($Matches[1], [ref]$ver) }
            [pscustomobject]@{ File=$f; Version=$ver }
        }
        $ranked = @($ranked | Sort-Object Version, @{Expression={$_.File.LastWriteTimeUtc}} -Descending)
        # Fully automatic: highest [vNNNN] wins; newest file wins if versions tie.
        $GameFile = $ranked[0].File.FullName
    } else {
        $GameFile = Join-Path $gameFolder 'The Legend of Zelda Ocarina of Time [0400486024DEC000][v131072].nup'
    }
}
$GameFile = [IO.Path]::GetFullPath($GameFile)

# ---------------------------------------------------------------------------
#  LATEST OFFICIAL WINDOWS RELEASE - fetched dynamically from the GitHub API
# ---------------------------------------------------------------------------
$AppVersion = 'not checked (revert)'
$AppZipName = ''
$AppZipUrl = ''
$AppZipSha256 = ''
$AppZipBytes = 0L
if (-not $Revert) {
    $GitHubReleaseApi = 'https://api.github.com/repos/Frizti/Fritchii/releases?per_page=100'
    try {
        $releaseList = @(Invoke-RestMethod -Uri $GitHubReleaseApi -Headers @{ 'User-Agent' = 'Fritchii-OoT-Setup'; 'Accept' = 'application/vnd.github+json' } -TimeoutSec 30)
    } catch {
        throw "Could not read Fritchii's official GitHub release list: $($_.Exception.Message). No older version will be installed silently."
    }
    $chosenRelease = $null
    $releaseAsset = $null
    foreach ($rel in ($releaseList | Where-Object { -not $_.draft } | Sort-Object { [datetime]$_.published_at } -Descending)) {
        $asset = @($rel.assets | Where-Object { $_.name -match '(?i)^Fritchii.*Windows.*x64.*\.zip$' -and $_.name -notmatch 'debug|symbols|source' } | Select-Object -First 1)
        if ($asset.Count -gt 0) { $chosenRelease = $rel; $releaseAsset = $asset[0]; break }
    }
    # GitHub's releases-list API can briefly omit the newest pre-release asset
    # while the public release page already exposes it. Fall back to that same
    # official release page and its expanded asset list; never guess a URL.
    if ($true) {
        try {
            $releasePage = (Invoke-WebRequest -Uri 'https://github.com/Frizti/Fritchii/releases' -UseBasicParsing -TimeoutSec 30).Content
            $tagMatch = [regex]::Match([string]$releasePage, 'href="/Frizti/Fritchii/releases/tag/(?<tag>[^"/?#]+)"', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if (-not $tagMatch.Success) { throw 'Could not identify the newest Fritchii release tag on GitHub.' }
            $latestTag = [uri]::UnescapeDataString($tagMatch.Groups['tag'].Value)
            if ($releaseAsset -and $chosenRelease -and [string]$chosenRelease.tag_name -eq $latestTag) {
                $releaseFallbackError = ''
            } else {
            # Once the web page identifies a different newest tag, discard any
            # older API candidate. If the new asset cannot be resolved, abort.
            $releaseAsset = $null
            $chosenRelease = $null
            $tagRelease = $null
            try { $tagRelease = Invoke-RestMethod -Uri ('https://api.github.com/repos/Frizti/Fritchii/releases/tags/' + [uri]::EscapeDataString($latestTag)) -Headers @{ 'User-Agent' = 'Fritchii-OoT-Setup'; 'Accept' = 'application/vnd.github+json' } -TimeoutSec 30 } catch { }
            $tagAsset = @($tagRelease.assets | Where-Object { $_.name -match '(?i)^Fritchii.*Windows.*x64.*\.zip$' -and $_.name -notmatch 'debug|symbols|source' } | Select-Object -First 1)
            if ($tagAsset.Count -gt 0) {
                $chosenRelease = $tagRelease
                $releaseAsset = $tagAsset[0]
            } else {
                $expandedAssets = (Invoke-WebRequest -Uri ('https://github.com/Frizti/Fritchii/releases/expanded_assets/' + [uri]::EscapeDataString($latestTag)) -UseBasicParsing -TimeoutSec 30).Content
                foreach ($linkMatch in [regex]::Matches([string]$expandedAssets, 'href="(?<url>(?:https://github\.com)?/Frizti/Fritchii/releases/download/[^" ]+?\.zip)"', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
                    $assetUrl = [Net.WebUtility]::HtmlDecode($linkMatch.Groups['url'].Value)
                    if ($assetUrl.StartsWith('/')) { $assetUrl = 'https://github.com' + $assetUrl }
                    $assetName = [IO.Path]::GetFileName(([uri]$assetUrl).AbsolutePath)
                    if ($assetName -notmatch '(?i)^Fritchii.*Windows.*x64.*\.zip$' -or $assetName -match '(?i)debug|symbols|source') { continue }
                    $releaseText = [Net.WebUtility]::HtmlDecode([regex]::Replace([string]$expandedAssets, '<[^>]+>', ' '))
                    $releaseText = [regex]::Replace($releaseText, '\s+', ' ')
                    $digest = ''
                    $assetInfo = [regex]::Match($releaseText, [regex]::Escape($assetName) + '.{0,250}?sha256:([a-fA-F0-9]{64})', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
                    if ($assetInfo.Success) { $digest = 'sha256:' + $assetInfo.Groups[1].Value.ToLowerInvariant() }
                    $releaseAsset = [pscustomobject]@{ name=$assetName; browser_download_url=$assetUrl; digest=$digest; size=0L }
                    $chosenRelease = [pscustomobject]@{ tag_name=$latestTag; published_at='(from official GitHub release page)'; html_url=('https://github.com/Frizti/Fritchii/releases/tag/' + $latestTag); body='Asset metadata came from the official GitHub release asset page.' }
                    Write-Log 'The GitHub API omitted the newest release asset or showed a different release; using the verified official release/assets page as a fallback.' 'WARN'
                    break
                }
            }
            }
        } catch {
            $releaseFallbackError = $_.Exception.Message
        }
    }
    if ($null -eq $chosenRelease -or $null -eq $releaseAsset -or [string]::IsNullOrWhiteSpace($releaseAsset.browser_download_url)) {
        $tagSummary = (@($releaseList | Select-Object -First 5 | ForEach-Object { [string]$_.tag_name }) -join ', ')
        throw "No official Fritchii Windows x64 ZIP was found. API tags: $tagSummary. GitHub page fallback: $releaseFallbackError. Installation is stopping without selecting an older version."
    }
    $AppVersion = [string]$chosenRelease.tag_name
    $AppZipName = [string]$releaseAsset.name
    $AppZipUrl = [string]$releaseAsset.browser_download_url
    if ($releaseAsset.digest -match '^sha256:([a-fA-F0-9]{64})$') { $AppZipSha256 = $Matches[1].ToLowerInvariant() }
    $AppZipBytes = [long]$releaseAsset.size
}

$TitleId      = '0400486024DEC000'
$PortableUser = Join-Path $InstallDir 'user'
if (Test-Path -LiteralPath $PortableUser -PathType Container) {
    $EdenRoot = $PortableUser
} else {
    $EdenRoot = Join-Path $env:APPDATA 'eden'
}
$EdenCustom   = Join-Path $EdenRoot 'config\custom'
$GameIni      = Join-Path $EdenCustom "$TitleId.ini"
$SwitchFile   = Join-Path $EdenRoot 'nx2_switches.txt'
$StateDir     = Join-Path $EdenRoot 'venice-oot-setup'
$StateFile    = Join-Path $StateDir 'state.json'
$OnlineReport = Join-Path $StateDir 'LATEST_ONLINE_SCAN.txt'
$WorkDir      = Join-Path $env:TEMP 'venice-oot-setup'
$ExeName      = 'lichii.exe'
$LogFile      = Join-Path $StateDir 'install.log'
$ReportFile   = Join-Path $StateDir 'RAPPORT.txt'
$Timestamp    = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupDir    = Join-Path $StateDir "backup-$Timestamp"
$switchFileExistedBefore = Test-Path -LiteralPath $SwitchFile
$desktopPath  = [Environment]::GetFolderPath('Desktop')
$gameShortcutPath = Join-Path $desktopPath 'The Legend of Zelda Ocarina of Time.lnk'
$emulatorShortcutPath = Join-Path $desktopPath 'Fritchii.lnk'
$NL           = [Environment]::NewLine

# Check latest news first, then compare the installation with the selected release.
$priorState = $null
if (Test-Path -LiteralPath $StateFile -PathType Leaf) {
    try { $priorState = Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json }
    catch { Write-Host 'WARNING: Previous installation state could not be read; a full check will be performed.' -ForegroundColor Yellow }
}
if ($priorState.BackupDir -and (Test-Path -LiteralPath $priorState.BackupDir -PathType Container)) {
    $BackupDir = [string]$priorState.BackupDir
}
$assetMetadataChanged = $false
if ($priorState -and $priorState.PSObject.Properties['AppAssetBytes'] -and [long]$priorState.AppAssetBytes -gt 0 -and [long]$priorState.AppAssetBytes -ne $AppZipBytes) {
    $assetMetadataChanged = $true
}
if ($priorState -and $AppZipSha256 -and $priorState.PSObject.Properties['AppAssetSha256'] -and
    -not [string]::IsNullOrWhiteSpace([string]$priorState.AppAssetSha256) -and
    ([string]$priorState.AppAssetSha256).ToLowerInvariant() -ne $AppZipSha256) {
    $assetMetadataChanged = $true
}
# ---------------------------------------------------------------------------
#  LOGGING
# ---------------------------------------------------------------------------
$script:Warnings = New-Object System.Collections.Generic.List[string]
$script:Changes  = New-Object System.Collections.Generic.List[string]

function Write-Log {
    param([string]$Text, [string]$Level = 'INFO')
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'HH:mm:ss'), $Level, $Text
    switch ($Level) {
        'OK'    { Write-Host "  [OK]   $Text" -ForegroundColor Green }
        'WARN'  { Write-Host "  [WARNING] $Text" -ForegroundColor Yellow }
        'ERROR' { Write-Host "  [ERROR] $Text" -ForegroundColor Red }
        'STEP'  { Write-Host "$NL== $Text" -ForegroundColor Cyan }
        default { Write-Host "  $Text" }
    }
    if (-not $DryRun -and (Test-Path $StateDir)) {
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
    }
    if ($Level -eq 'WARN') { $script:Warnings.Add($Text) }
}

function Invoke-StartupNewsScan {
    param([object]$Release, [string]$ReportPath)
    $script:OnlineFindings = New-Object System.Collections.Generic.List[string]
    $script:OnlineFindings.Add(('ONLINE SOURCE SCAN - {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm')))
    $script:OnlineFindings.Add('Scope: Fritchii + Zelda OoT on Windows 11. Search results are leads; no external cache or tweak is applied automatically.')
    $script:OnlineFindings.Add('')
    if ($Release) {
        $script:OnlineFindings.Add(('LATEST OFFICIAL FRITCHII RELEASE: {0} | {1}' -f $Release.tag_name, $Release.published_at))
        $script:OnlineFindings.Add([string]$Release.html_url)
        $releaseNotes = [string]$Release.body
        if ($releaseNotes.Length -gt 7000) { $releaseNotes = $releaseNotes.Substring(0,7000) + "`r`n... [truncated]" }
        $script:OnlineFindings.Add($releaseNotes)
    }
    $script:OnlineFindings.Add('')

    $apiHeaders = @{ 'User-Agent' = 'Fritchii-OoT-Windows11-Source-Scan'; 'Accept' = 'application/vnd.github+json' }
    try {
        $issues = @(Invoke-RestMethod -Uri 'https://api.github.com/repos/Frizti/Fritchii/issues?state=all&sort=updated&direction=desc&per_page=50' -Headers $apiHeaders -TimeoutSec 30)
        $relevant = @($issues | Where-Object {
            $_.pull_request -eq $null -and (($_.title + ' ' + $_.body) -match '(?i)shader|pipeline|stutter|frame.?time|fps|vulkan|windows.?11|nvidia|amd|intel|driver|cache|recommend')
        } | Select-Object -First 10)
        $script:OnlineFindings.Add('RECENT FRITCHII DEVELOPER / USER ISSUES')
        if ($relevant.Count -eq 0) { $script:OnlineFindings.Add('No matching issue found in the 50 most recently updated.') }
        foreach ($issue in $relevant) {
            $script:OnlineFindings.Add(('[{0}] {1} | {2}' -f $issue.state, $issue.title, $issue.html_url))
            $excerpt = [Net.WebUtility]::HtmlDecode([regex]::Replace([string]$issue.body, '<[^>]+>', ' '))
            $excerpt = [regex]::Replace($excerpt, '\s+', ' ').Trim()
            if ($excerpt.Length -gt 400) { $excerpt = $excerpt.Substring(0,400) + '...' }
            if ($excerpt) { $script:OnlineFindings.Add($excerpt) }
        }
    } catch { $script:OnlineFindings.Add(('Fritchii issue search failed: {0}' -f $_.Exception.Message)) }
    $script:OnlineFindings.Add('')

    function Add-DriverSearchResults {
        param([string]$Vendor, [string]$Domain, [string]$Query)
        $script:OnlineFindings.Add(($Vendor + ' OFFICIAL DRIVER SEARCH'))
        try {
            $uri = 'https://www.bing.com/search?format=rss&q=' + [uri]::EscapeDataString($Query)
            $feed = Invoke-RestMethod -Uri $uri -Headers @{ 'User-Agent' = 'Mozilla/5.0 Fritchii-OoT-Windows11-Source-Scan' } -TimeoutSec 30
            $count = 0
            foreach ($item in @($feed.rss.channel.item | Select-Object -First 10)) {
                $link = [string]$item.link
                $hostName = ''
                try { $hostName = ([uri]$link).Host } catch {}
                if (-not ($hostName -eq $Domain -or $hostName.EndsWith('.' + $Domain, [StringComparison]::OrdinalIgnoreCase))) { continue }
                $title = [Net.WebUtility]::HtmlDecode([string]$item.title)
                $description = [Net.WebUtility]::HtmlDecode([regex]::Replace([string]$item.description, '<[^>]+>', ' '))
                $description = [regex]::Replace($description, '\s+', ' ').Trim()
                if ($description.Length -gt 300) { $description = $description.Substring(0,300) + '...' }
                $script:OnlineFindings.Add(('{0} | {1} | {2}' -f $item.pubDate, $title, $link))
                if ($description) { $script:OnlineFindings.Add($description) }
                $count++
                if ($count -ge 4) { break }
            }
            if ($count -eq 0) { $script:OnlineFindings.Add('No vendor-domain result in this search response.') }
        } catch { $script:OnlineFindings.Add(('Search failed: {0}' -f $_.Exception.Message)) }
        $script:OnlineFindings.Add('')
    }

    Add-DriverSearchResults -Vendor 'NVIDIA' -Domain 'nvidia.com' -Query 'site:nvidia.com/en-us/geforce/news OR site:nvidia.com/en-us/geforce/drivers Windows 11 Game Ready driver release notes shader compilation stutter frame time'
    Add-DriverSearchResults -Vendor 'AMD' -Domain 'amd.com' -Query 'site:amd.com/en/resources/support-articles/release-notes OR site:amd.com/en/support/download/drivers Windows 11 Radeon Adrenalin release notes shader stutter frame time'
    Add-DriverSearchResults -Vendor 'Intel' -Domain 'intel.com' -Query 'site:intel.com/content/www/us/en/download-center OR site:intel.com/content/www/us/en/support/articles graphics driver release notes Windows 11 Vulkan shader performance'

    $script:OnlineFindings.Add('MICROSOFT WINDOWS PERFORMANCE GUIDANCE (official search results)')
    try {
        $windowsQuery = 'site:support.microsoft.com/en-us/windows Windows 11 improve PC performance gaming Game Mode Storage Sense power mode graphics'
        $uri = 'https://www.bing.com/search?format=rss&q=' + [uri]::EscapeDataString($windowsQuery)
        $feed = Invoke-RestMethod -Uri $uri -Headers @{ 'User-Agent' = 'Mozilla/5.0 Fritchii-OoT-Windows11-Source-Scan' } -TimeoutSec 30
        $count = 0
        foreach ($item in @($feed.rss.channel.item | Select-Object -First 12)) {
            $link = [string]$item.link
            $hostName = ''
            try { $hostName = ([uri]$link).Host } catch {}
            if (-not ($hostName -eq 'support.microsoft.com' -or $hostName -eq 'learn.microsoft.com' -or $hostName.EndsWith('.support.microsoft.com', [StringComparison]::OrdinalIgnoreCase) -or $hostName.EndsWith('.learn.microsoft.com', [StringComparison]::OrdinalIgnoreCase))) { continue }
            $script:OnlineFindings.Add(('{0} | {1} | {2}' -f $item.pubDate, [Net.WebUtility]::HtmlDecode([string]$item.title), $link))
            $count++
            if ($count -ge 5) { break }
        }
        if ($count -eq 0) { $script:OnlineFindings.Add('No Microsoft-domain result in this search response.') }
    } catch { $script:OnlineFindings.Add(('Microsoft Windows guidance search failed: {0}' -f $_.Exception.Message)) }
    $script:OnlineFindings.Add('')

    $script:OnlineFindings.Add('EMULATOR USER / COMMUNITY SEARCH (unverified leads)')
    try {
        $communityQuery = 'Fritchii Ocarina of Time Windows 11 emulator shader cache pipeline stutter frame time recommendation'
        $uri = 'https://www.bing.com/search?format=rss&q=' + [uri]::EscapeDataString($communityQuery)
        $feed = Invoke-RestMethod -Uri $uri -Headers @{ 'User-Agent' = 'Mozilla/5.0 Fritchii-OoT-Windows11-Source-Scan' } -TimeoutSec 30
        foreach ($item in @($feed.rss.channel.item | Select-Object -First 8)) {
            $script:OnlineFindings.Add(('{0} | {1} | {2}' -f $item.pubDate, [Net.WebUtility]::HtmlDecode([string]$item.title), [string]$item.link))
        }
    } catch { $script:OnlineFindings.Add(('Community search failed: {0}' -f $_.Exception.Message)) }
    $script:OnlineFindings.Add('')

    $script:OnlineFindings.Add('WIDER WINDOWS GAMING COMMUNITY / INDEPENDENT TEST SEARCH (unverified; conflicting reports retained)')
    try {
        $wideQuery = 'Windows 11 gaming performance benchmark stutter frame time HAGS Game Mode power settings startup background processes'
        $uri = 'https://www.bing.com/search?format=rss&q=' + [uri]::EscapeDataString($wideQuery)
        $feed = Invoke-RestMethod -Uri $uri -Headers @{ 'User-Agent' = 'Mozilla/5.0 Fritchii-OoT-Windows11-Source-Scan' } -TimeoutSec 30
        foreach ($item in @($feed.rss.channel.item | Select-Object -First 10)) {
            $script:OnlineFindings.Add(('{0} | {1} | {2}' -f $item.pubDate, [Net.WebUtility]::HtmlDecode([string]$item.title), [string]$item.link))
        }
    } catch { $script:OnlineFindings.Add(('Wider community search failed: {0}' -f $_.Exception.Message)) }
    $script:OnlineFindings.Add('')
    $script:OnlineFindings.Add('Cache policy: retain and reuse Fritchii shader/pipeline cache across game restarts and save-file resets. Do not delete cache after every build; let Fritchii prepare/rebuild its local cache. Clear it only for a confirmed cache problem using Fritchii Help > Delete Shader Cache.')
    $script:OnlineFindings.Add('Windows policy: this installer sets High performance GPU only for lichii.exe in the current user profile. Windows windowed-game optimizations are for DirectX 10/11; Fritchii uses Vulkan, so this script does not force that toggle.')
    $script:OnlineFindings.Add('Cleanup policy: each normal start attempts to remove files older than 14 days from this Windows user temp folder; locked files are skipped. This is targeted temporary-file cleanup, not a guaranteed FPS boost.')
    $script:OnlineFindings.Add('Memory policy: no RAM/standby-list cleaner is run. Windows manages these caches; flushing them can force disk reads and worsen loading or frame-time stutter.')
    $script:OnlineFindings.Add('Disk policy: no broad disk-cleaner run on every launch. Windows Storage Sense is Microsoft supported automatic cleanup option; this script does not delete Downloads, Recycle Bin contents, update rollback data, or graphics caches.')
    $script:OnlineFindings.Add('CachyOS comparison: BORE and sched-ext are Linux-kernel CPU schedulers and cannot be loaded into the Windows NT kernel. WSL2 runs a Linux kernel inside a VM; it cannot reschedule a native Windows lichii.exe process.')
    $script:OnlineFindings.Add('Windows-native analogues used here: Game Mode, permanent maximum processor boost power plan, per-app high-performance GPU selection, and built-in Fritchii GPU-thread/game-clock handling.')
    $script:OnlineFindings.Add('Stutter check: follow the shader/pipeline preparation and cache instructions in the latest release notes printed above. Do not interrupt a preparation pass or routinely delete the emulator/driver cache. If hitches continue after preparation, use Fritchii View > Performance Overlay (when available) and Help > Export Log.')
    $script:OnlineFindings.Add('GPU-vendor cache and shader preparation behavior can change by Fritchii release and driver; use the current release notes and the emulator own controls. Do not apply global vendor overrides or cache deletion as a routine tweak.')
    $script:OnlineFindings.Add('No search result is applied blindly. Community and benchmark claims can conflict. This installer applies reversible Game Mode, permanent Windows power plan, and per-app GPU preference; it leaves Fritchii-tuned renderer/CPU/shader settings alone.')

    if (-not $DryRun) {
        New-Dir (Split-Path -Parent $ReportPath)
        $script:OnlineFindings | Set-Content -LiteralPath $ReportPath -Encoding UTF8
    }
    Write-Log "Online source scan complete. Report: $ReportPath" 'OK'
    Write-Host "  Latest Fritchii release: $($Release.tag_name)" -ForegroundColor Cyan
    Write-Host "  Driver updates, developer issues, and community findings searched. Report: $ReportPath" -ForegroundColor Cyan
}

function Clear-StaleUserTempFiles {
    # Old files in the current user's TEMP directory are the only Windows files
    # cleaned automatically. Preserve cache/shader/GPU-cache paths, Prefetch,
    # Downloads, and all other users' profiles. A 14-day age limit avoids
    # touching active temporary work.
    $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
    $userTemp = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Temp')).TrimEnd('\')
    if (-not $tempRoot.Equals($userTemp, [StringComparison]::OrdinalIgnoreCase)) {
        Write-Log 'Temporary-file cleanup skipped: TEMP does not point to this profile standard Temp folder.' 'WARN'
        return
    }
    if (-not (Test-Path -LiteralPath $userTemp -PathType Container)) { return }
    $cutoff = (Get-Date).AddDays(-14)
    $cachePathPattern = '(?i)(^|[\\/])(?:cache|shadercache|shader-cache|pipeline|pipelinecache|dxcache|glcache|vulkan|nvidia|amd|intel)(?:[\\/._-]|$)'
    $deleted = 0
    $freed = [long]0
    if ($DryRun) {
        $stale = @(Get-ChildItem -LiteralPath $userTemp -File -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cutoff -and $_.FullName -notmatch $cachePathPattern })
        Write-Log "Temporary-file check: $($stale.Count) files older than 14 days would be removed from this user's Temp folder." 'INFO'
        return
    }
    foreach ($file in @(Get-ChildItem -LiteralPath $userTemp -File -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cutoff -and $_.FullName -notmatch $cachePathPattern })) {
        try {
            $full = [IO.Path]::GetFullPath($file.FullName)
            if (-not $full.StartsWith($userTemp + '\', [StringComparison]::OrdinalIgnoreCase)) { continue }
            $length = [long]$file.Length
            Remove-Item -LiteralPath $full -Force -ErrorAction Stop
            $deleted++
            $freed += $length
        } catch { }
    }
    Write-Log "Windows Temp cleanup: removed $deleted files older than 14 days, about $([math]::Round($freed / 1MB, 1)) MB. Locked files and shader/driver caches are preserved." 'OK'
}

function Write-Change {
    param([string]$Text)
    $script:Changes.Add($Text)
    Write-Log $Text 'OK'
}

function Get-ActivePowerSchemeGuid {
    $powerCfg = Join-Path $env:windir 'System32\powercfg.exe'
    try {
        $result = @(& $powerCfg /getactivescheme 2>$null)
        if ($LASTEXITCODE -eq 0 -and ($result -join ' ') -match '(?i)([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})') {
            return $Matches[1].ToLowerInvariant()
        }
    } catch {}
    return $null
}

function New-Dir {
    param([string]$Path)
    if ($DryRun) { if (-not (Test-Path $Path)) { Write-Log "Would create folder: $Path" } ; return }
    if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function Stop-Script {
    param([string]$Message)
    Write-Log $Message 'ERROR'
    Write-Host ''
    Write-Host 'Aborted. No further changes were made.' -ForegroundColor Red
    if (-not $DryRun) { Write-Host "Log: $LogFile" -ForegroundColor DarkGray }
    exit 1
}

# ---------------------------------------------------------------------------
#  ADMINISTRATOR STATUS - needed for the permanent power plan
# ---------------------------------------------------------------------------
$identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin   = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and $DryRun) { Write-Log 'Dry run is running without elevation. A real setup will request administrator approval for the permanent power plan.' }

# ---------------------------------------------------------------------------
#  START
# ---------------------------------------------------------------------------
Write-Host ''
Write-Host '==================================================================' -ForegroundColor White
Write-Host "  Fritchii $AppVersion - Ocarina of Time (Switch 2) - complete setup" -ForegroundColor White
Write-Host '  Title ID 0400486024DEC000 | NUP container | Windows x64' -ForegroundColor DarkGray
if ($DryRun) { Write-Host '  MODE: DRY RUN - no changes will be made' -ForegroundColor Yellow }
if ($Revert) { Write-Host '  MODE: REVERT' -ForegroundColor Yellow }
Write-Host '==================================================================' -ForegroundColor White

if (-not $DryRun) {
    New-Dir $StateDir
    New-Dir $WorkDir
    "=== Korning $Timestamp (PS $($PSVersionTable.PSVersion)) ===" | Add-Content -LiteralPath $LogFile -Encoding UTF8
}

# Search current public sources first, then recheck local install and settings.
if (-not $Revert) {
    Invoke-StartupNewsScan -Release $chosenRelease -ReportPath $OnlineReport
    Clear-StaleUserTempFiles
    $installedFilesValid = $false
    if ($priorState -and $priorState.InstalledFiles) {
        $installedFilesValid = $true
        foreach ($relativePath in @($priorState.InstalledFiles)) {
            if (-not (Test-Path -LiteralPath (Join-Path $InstallDir ([string]$relativePath)) -PathType Leaf)) {
                $installedFilesValid = $false
                break
            }
        }
    }
    $installedExeForCheck = Join-Path $InstallDir $ExeName
    $hasInstalledRelease = (Test-Path -LiteralPath $installedExeForCheck -PathType Leaf) -and
        ($null -ne $priorState) -and ([string]$priorState.Version -eq $AppVersion) -and $installedFilesValid -and (-not $assetMetadataChanged)
    if ($hasInstalledRelease) {
        Write-Host "Local check: Fritchii $AppVersion is installed; checking configuration and desktop shortcuts." -ForegroundColor Green
    } else {
        Write-Host "Local check: Fritchii $AppVersion is missing, incomplete, or needs an update." -ForegroundColor Cyan
        if ($chosenRelease.body) {
            $newsPreview = [string]$chosenRelease.body
            if ($newsPreview.Length -gt 3000) { $newsPreview = $newsPreview.Substring(0,3000) + "`r`n... fulla nyheter finns i $OnlineReport" }
            Write-Host $newsPreview
        }
    }
}

# ===========================================================================
#  REVERT
# ===========================================================================
if ($Revert) {
Write-Log 'Revert changes' 'STEP'
    if (-not (Test-Path $StateFile)) { Stop-Script "No state file found at $StateFile. Nothing to revert." }
    $state = Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json

    $backupGameIni = $null
    if ($state.BackupDir) { $backupGameIni = Join-Path ([string]$state.BackupDir) "$TitleId.ini" }
    if ($backupGameIni -and (Test-Path -LiteralPath $backupGameIni -PathType Leaf)) {
        if ($DryRun) { Write-Log "Would restore original game INI: $GameIni" }
        else {
            New-Dir $EdenCustom
            Copy-Item -LiteralPath $backupGameIni -Destination $GameIni -Force
            Write-Log "Original game INI restored: $GameIni" 'OK'
        }
    } elseif (Test-Path -LiteralPath $GameIni -PathType Leaf) {
        $managedIniKeys = @(
            'Renderer/backend','Renderer/resolution_setup','Renderer/scaling_filter','Renderer/anti_aliasing',
            'Renderer/gpu_accuracy','Renderer/nvdec_emulation','Renderer/dyna_state','Renderer/use_asynchronous_shaders',
            'Renderer/async_presentation','Renderer/use_disk_shader_cache','Renderer/use_vulkan_driver_pipeline_cache',
            'Renderer/nx2_frame_rate_limit','System/use_docked_mode','System/fast_cpu_time','Cpu/cpu_accuracy',
            'Core/memory_layout_mode','Core/use_multi_core'
        )
        if ($DryRun) {
            Write-Log 'No original backup exists; only script-managed INI keys would be removed, preserving other user settings.' 'WARN'
        } else {
            $keptIniLines = New-Object System.Collections.Generic.List[string]
            $sectionForRevert = ''
            foreach ($iniLine in (Get-Content -LiteralPath $GameIni)) {
                if ($iniLine -match '^\s*\[([^\]]+)\]\s*$') { $sectionForRevert = $Matches[1]; $keptIniLines.Add([string]$iniLine); continue }
                $removeThis = $false
                if ($iniLine -match '^\s*([^;=#]+?)\s*=') {
                    $iniKeyName = $Matches[1].Trim()
                    $iniKeyPath = "$sectionForRevert/$iniKeyName"
                    foreach ($managedKeyPath in $managedIniKeys) {
                        if ($iniKeyPath -eq $managedKeyPath -or $iniKeyPath -eq ($managedKeyPath + '\default') -or $iniKeyPath -eq ($managedKeyPath + '\use_global')) { $removeThis = $true; break }
                    }
                }
                if (-not $removeThis) { $keptIniLines.Add([string]$iniLine) }
            }
            Set-Content -LiteralPath $GameIni -Value ($keptIniLines.ToArray()) -Encoding UTF8
            Write-Log 'Script-managed INI overrides removed; other user settings preserved.' 'OK'
        }
    } else {
        Write-Log 'No game INI to restore.' 'INFO'
    }

    $shortcutBackupProperty = $state.PSObject.Properties['GameShortcutBackup']
    if ($null -ne $shortcutBackupProperty) {
        if ($state.GameShortcutBackup -and (Test-Path -LiteralPath $state.GameShortcutBackup)) {
            Copy-Item -LiteralPath $state.GameShortcutBackup -Destination $gameShortcutPath -Force
            Write-Log 'Previous Zelda desktop shortcut restored.' 'OK'
        } elseif (-not $state.GameShortcutExistedBefore -and (Test-Path -LiteralPath $gameShortcutPath)) {
            Remove-Item -LiteralPath $gameShortcutPath -Force
            Write-Log 'Script-created Zelda desktop shortcut removed.' 'OK'
        }
    }
    $emulatorShortcutBackupProperty = $state.PSObject.Properties['EmulatorShortcutBackup']
    if ($null -ne $emulatorShortcutBackupProperty) {
        if ($state.EmulatorShortcutBackup -and (Test-Path -LiteralPath $state.EmulatorShortcutBackup)) {
            Copy-Item -LiteralPath $state.EmulatorShortcutBackup -Destination $emulatorShortcutPath -Force
            Write-Log 'Previous Fritchii desktop shortcut restored.' 'OK'
        } elseif (-not $state.EmulatorShortcutExistedBefore -and (Test-Path -LiteralPath $emulatorShortcutPath)) {
            Remove-Item -LiteralPath $emulatorShortcutPath -Force
            Write-Log 'Script-created Fritchii desktop shortcut removed.' 'OK'
        }
    }

    $gpuKey = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $exeFull = Join-Path $InstallDir $ExeName
    if ($DryRun) {
        Write-Log "Would restore previous GPU preference for $exeFull"
    } else {
        $oldGpu = $state.PSObject.Properties['OriginalGpuPreference']
        if ($null -ne $oldGpu -and $null -ne $oldGpu.Value -and [string]$oldGpu.Value -ne '') {
            if (-not (Test-Path $gpuKey)) { New-Item -Path $gpuKey -Force | Out-Null }
            New-ItemProperty -Path $gpuKey -Name $exeFull -Value ([string]$oldGpu.Value) -PropertyType String -Force | Out-Null
        } elseif (Test-Path $gpuKey) {
            Remove-ItemProperty -Path $gpuKey -Name $exeFull -ErrorAction SilentlyContinue
        }
    }

    $gameBarKey = 'HKCU:\Software\Microsoft\GameBar'
    $oldGameModeExisted = $state.PSObject.Properties['OriginalGameModeExisted']
    $oldGameModeValue = $state.PSObject.Properties['OriginalGameModeValue']
    if ($DryRun) {
        Write-Log 'Would restore the previous Windows Game Mode setting.'
    } elseif ($null -ne $oldGameModeExisted -and $state.OriginalGameModeExisted -and $null -ne $oldGameModeValue) {
        if (-not (Test-Path $gameBarKey)) { New-Item -Path $gameBarKey -Force | Out-Null }
        New-ItemProperty -Path $gameBarKey -Name 'AutoGameModeEnabled' -Value ([int]$state.OriginalGameModeValue) -PropertyType DWord -Force | Out-Null
        Write-Log 'Previous Windows Game Mode setting restored.' 'OK'
    } elseif ($null -ne $oldGameModeExisted -and (Test-Path $gameBarKey)) {
        Remove-ItemProperty -Path $gameBarKey -Name 'AutoGameModeEnabled' -ErrorAction SilentlyContinue
        Write-Log 'Script-managed Windows Game Mode setting removed; the Windows default applies again.'
    }

    $powerCfg = Join-Path $env:windir 'System32\powercfg.exe'
    $oldPowerScheme = $state.PSObject.Properties['OriginalPowerSchemeGuid']
    $managedPowerScheme = $state.PSObject.Properties['ManagedPowerSchemeGuid']
    if ($DryRun) {
        if ($null -ne $oldPowerScheme -and $state.OriginalPowerSchemeGuid) { Write-Log "Would restore previous Windows power scheme: $($state.OriginalPowerSchemeGuid)" }
        else { Write-Log 'No saved original power scheme is available to restore.' }
        if ($null -ne $managedPowerScheme -and $state.ManagedPowerSchemeGuid) { Write-Log "Would delete script-managed power plan: $($state.ManagedPowerSchemeGuid)" }
    } else {
        $activeBeforeRevert = Get-ActivePowerSchemeGuid
        if ($null -ne $oldPowerScheme -and $state.OriginalPowerSchemeGuid) {
            $availableSchemes = @(& $powerCfg /list 2>$null)
            if (($availableSchemes -join "`n") -match [regex]::Escape([string]$state.OriginalPowerSchemeGuid)) {
                & $powerCfg /setactive ([string]$state.OriginalPowerSchemeGuid) 2>$null | Out-Null
                if ($LASTEXITCODE -eq 0) { Write-Log 'Previous Windows power scheme restored.' 'OK' }
                else { Write-Log 'Could not restore the previous Windows power scheme.' 'WARN' }
            } else { Write-Log 'Saved original power scheme no longer exists; unable to restore it.' 'WARN' }
        }
        if ($null -ne $managedPowerScheme -and $state.ManagedPowerSchemeGuid -and [string]$state.ManagedPowerSchemeGuid -notin @('8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c','381b4222-f694-41f0-9685-ff5bb260df2e','a1841308-3541-4fab-bc81-f71556f20b4a')) {
            $activeNow = Get-ActivePowerSchemeGuid
            if ($activeNow -ne [string]$state.ManagedPowerSchemeGuid) {
                & $powerCfg /delete ([string]$state.ManagedPowerSchemeGuid) 2>$null | Out-Null
                if ($LASTEXITCODE -eq 0) { Write-Log 'Script-managed maximum performance power plan deleted.' 'OK' }
                else { Write-Log 'Could not delete the script-managed power plan.' 'WARN' }
            } else { Write-Log 'Script-managed power plan remains active; it was not deleted.' 'WARN' }
        }
    }

    Write-Log 'Windows changes reverted.' 'OK'
    Write-Host ''
    if ($DryRun) { Write-Host 'Revert dry run complete.' -ForegroundColor Yellow }
    else { Write-Host 'Done. Restart the computer to release all changes.' -ForegroundColor Green }
    exit 0
}

# ===========================================================================
#  PREFLIGHT CHECKS
# ===========================================================================
Write-Log 'Preflight checks' 'STEP'

if (-not [Environment]::Is64BitOperatingSystem) { Stop-Script '64-bit Windows is required.' }
$windowsVersionKey = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
$windowsBuild = [int]$windowsVersionKey.CurrentBuildNumber
$windowsCaption = [string]$windowsVersionKey.ProductName
if ($windowsBuild -lt 22000 -or $windowsCaption -notmatch 'Windows') { Stop-Script 'This script is designed for Windows 11 x64.' }
if ($windowsBuild -ge 22000 -and $windowsCaption -match '^Windows 10') { $windowsCaption = $windowsCaption -replace '^Windows 10','Windows 11' }
Write-Log "Windows 11 or later detected: build $windowsBuild. Future build numbers are not blocked."

if (-not (Test-Path -LiteralPath $InstallDir -PathType Container)) {
    Stop-Script "Emulator folder not found: $InstallDir. Place the CMD file in the emulator folder and check the path."
}
if (-not (Test-Path -LiteralPath $GameFile -PathType Leaf)) {
    Stop-Script "No game file was found. Place your own legally obtained, Fritchii-compatible Ocarina of Time .nup file in the .\Spel\ subfolder, or specify its full path with -GameFile. The installer does not download or include the game."
}
if ([IO.Path]::GetExtension($GameFile) -ne '.nup') {
    Stop-Script 'The game file must be a .nup container supported by Fritchii.'
}
Write-Log "Game file found: $GameFile"
Write-Log 'The emulator NUP reader uses the NUP file directly; do NOT extract it as a ZIP.'

$os = $null
try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch {}
Write-Log "OS: $windowsCaption build $windowsBuild"
$freeMemoryBytes = if ($os -and $os.FreePhysicalMemory) { [long]$os.FreePhysicalMemory * 1KB } else { $null }
if ($null -eq $freeMemoryBytes) {
    try { $freeMemoryBytes = [long](Get-Counter '\Memory\Available Bytes' -ErrorAction Stop).CounterSamples[0].CookedValue } catch {}
}
if ($null -ne $freeMemoryBytes -and $freeMemoryBytes -lt 4GB) {
    Write-Log ("Available RAM: {0:N1} GB - at least 4 GB free is recommended before launch." -f ($freeMemoryBytes/1GB)) 'WARN'
} elseif ($null -ne $freeMemoryBytes) {
    Write-Log ("Available RAM: {0:N1} GB" -f ($freeMemoryBytes/1GB))
} else { Write-Log 'Available RAM could not be read through Windows system inventory; continuing.' 'INFO' }

$gpus = @()
try { $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction Stop) }
catch { Write-Log 'Windows CIM hardware inventory is unavailable; GPU model checks are skipped. The per-app GPU preference is still applied.' 'WARN' }
$nvidia = $gpus | Where-Object { $_.Name -match 'NVIDIA' }
if (-not $nvidia) {
    Write-Log 'No NVIDIA GPU detected. The emulator Vulkan settings are used without NVIDIA-specific changes.' 'INFO'
} else {
    foreach ($g in $nvidia) {
        Write-Log "GPU: $($g.Name) (driver $($g.DriverVersion))"
        if ($g.Name -match 'GTX 10|GTX 9|GTX 7') {
            Write-Log 'GTX 10 series or older: mesh shaders are unavailable, so some vegetation may be missing (known limitation).' 'WARN'
        }
    }
}

$cpus = @()
try { $cpus = @(Get-CimInstance Win32_Processor -ErrorAction Stop) } catch {}
if ($cpus.Count -eq 0) {
    $processorInfo = Get-ItemProperty -LiteralPath 'HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0' -ErrorAction SilentlyContinue
    $cpuName = if ($processorInfo.ProcessorNameString) { [string]$processorInfo.ProcessorNameString.Trim() } else { 'CPU model unavailable' }
    $logicalProcessorCount = [Environment]::ProcessorCount
    $cpus = @([pscustomobject]@{ Name=$cpuName; NumberOfCores=$null; NumberOfLogicalProcessors=$logicalProcessorCount })
    Write-Log 'Windows CIM hardware inventory is unavailable; CPU information is read from the registry/runtime.' 'INFO'
}
$coreDescription = if ($cpus[0].NumberOfCores) { [string]$cpus[0].NumberOfCores } else { 'unknown' }
Write-Log "CPU: $($cpus[0].Name) ($coreDescription cores / $($cpus[0].NumberOfLogicalProcessors) threads)"
if ($cpus[0].NumberOfLogicalProcessors -and $cpus[0].NumberOfLogicalProcessors -lt 12) {
    Write-Log 'The CPU has fewer than 12 logical threads. 60 FPS may still be possible; check actual FPS and frame times in-game.' 'WARN'
}

$qualifier = Split-Path $InstallDir -Qualifier
if (-not $qualifier) { Stop-Script 'InstallDir must be an absolute path, for example C:\Games\Fritchii.' }
$driveLetter = $qualifier.TrimEnd(':')
$free = $null
try { $free = [long](Get-PSDrive $driveLetter -ErrorAction Stop).Free } catch {}
try {
    $driveInfo = [System.IO.DriveInfo]::new($qualifier + '\')
    if ($driveInfo.IsReady -and ($null -eq $free -or [long]$driveInfo.AvailableFreeSpace -gt $free)) { $free = [long]$driveInfo.AvailableFreeSpace }
} catch {}
if ($null -eq $free) { Stop-Script "Could not determine free disk space on $qualifier." }
Write-Log ("Available disk space on {0}: {1:N1} GB" -f $qualifier, ($free/1GB))
if ($free -lt 5GB) { Stop-Script "Less than 5 GB is available on $qualifier. Free disk space first." }

if (Get-Process -Name 'lichii' -ErrorAction SilentlyContinue) {
    if ($Force) { Write-Log 'lichii.exe is running; continuing because -Force was specified.' 'WARN' }
    else { Stop-Script 'lichii.exe is already running. Close the emulator and try again, or specify -Force.' }
}

# A compatible NUP container is read directly by the Fritchii NUP loader.
# The script never downloads or distributes prod.keys/firmware.
Write-Log 'The NUP file must be a valid game container readable by Fritchii. This script does not provide games, keys, or firmware.'

# ===========================================================================
#  1. DOWNLOAD AND EXTRACT
# ===========================================================================
Write-Log ("Latest official Fritchii version: $AppVersion") 'STEP'

$exePath = Join-Path $InstallDir $ExeName
$zipPath = Join-Path $WorkDir $AppZipName
$installedFiles = @()
$needsBinaryUpdate = -not (Test-Path -LiteralPath $exePath -PathType Leaf) -or
    ($null -eq $priorState) -or ([string]$priorState.Version -ne $AppVersion) -or (-not $installedFilesValid) -or $assetMetadataChanged


# Download only when the installed version is missing or older.
if (-not $needsBinaryUpdate) {
    Write-Log "Fritchii $AppVersion is already installed; emulator files are left unchanged." 'OK'
} elseif ($DryRun) {
    Write-Log "Would download missing/newer official version ${AppVersion}: $AppZipUrl"
    Write-Log "Would verify ZIP size and SHA-256 (if GitHub publishes a digest), extract ALL files, and update $InstallDir."
} else {
    New-Dir $WorkDir
    $extractDir = Join-Path $WorkDir ('Fritchii-' + ($AppVersion -replace '[^A-Za-z0-9._-]','_'))
    if (Test-Path -LiteralPath $extractDir) { Remove-Item -LiteralPath $extractDir -Recurse -Force }
    New-Dir $extractDir

    $ok = $false
    for ($i = 1; $i -le 3 -and -not $ok; $i++) {
        try {
            if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
            Write-Log "Downloading latest Fritchii $AppVersion ($i/3): $AppZipName"
            Invoke-WebRequest -Uri $AppZipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 900
            $ok = $true
        } catch {
            Write-Log "Download failed: $($_.Exception.Message)" 'WARN'
            Start-Sleep -Seconds (3 * $i)
        }
    }
    if (-not $ok) { Stop-Script 'Could not download the latest official Fritchii ZIP. No existing installation files were replaced.' }

    $archiveBytes = (Get-Item -LiteralPath $zipPath).Length
    if ($AppZipBytes -gt 0 -and $archiveBytes -ne $AppZipBytes) {
        Stop-Script "ZIP size does not match the GitHub release metadata ($archiveBytes bytes versus $AppZipBytes)."
    }
    $hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($AppZipSha256 -and $hash -ne $AppZipSha256) {
        Stop-Script "SHA-256 does not match GitHub's published digest. Extraction is stopping. Hash: $hash"
    }
    if ($AppZipSha256) { Write-Log "SHA-256 verifierad mot GitHub: $hash" 'OK' }
    else { Write-Log "GitHub does not publish a SHA-256 digest for this asset; calculated SHA-256: $hash. ZIP test and lichii.exe validation follow." 'WARN' }

    Write-Log 'Extracting the complete Windows archive to staging...'
    try { Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force -ErrorAction Stop }
    catch { Stop-Script "Could not extract the ZIP archive: $($_.Exception.Message)" }
    $foundExe = Get-ChildItem -LiteralPath $extractDir -Filter $ExeName -Recurse -File -ErrorAction Stop | Select-Object -First 1
    if (-not $foundExe) { Stop-Script 'The official ZIP does not contain lichii.exe. Installation is stopping.' }

    $topDirs = @(Get-ChildItem -LiteralPath $extractDir -Directory -Force)
    if ($foundExe.Directory.FullName -eq $extractDir) { $sourceRoot = $extractDir }
    elseif ($topDirs.Count -eq 1 -and $foundExe.FullName.StartsWith($topDirs[0].FullName, [StringComparison]::OrdinalIgnoreCase)) { $sourceRoot = $topDirs[0].FullName }
    else { $sourceRoot = $foundExe.Directory.FullName }
    New-Dir $InstallDir
    New-Dir $StateDir
    New-Dir $BackupDir
    $collisionBackup = Join-Path $BackupDir 'pre-update-files'
    $filesToInstall = @(Get-ChildItem -LiteralPath $sourceRoot -Recurse -File -Force)
    if ($filesToInstall.Count -eq 0) { Stop-Script 'The ZIP archive contains no program files.' }
    $installedFiles = @($filesToInstall | ForEach-Object { $_.FullName.Substring($sourceRoot.Length).TrimStart('\') })
    foreach ($srcFile in $filesToInstall) {
        $relative = $srcFile.FullName.Substring($sourceRoot.Length).TrimStart('\')
        $destination = Join-Path $InstallDir $relative
        $destParent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $destParent)) { New-Item -ItemType Directory -Path $destParent -Force | Out-Null }
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            $backupFile = Join-Path $collisionBackup $relative
            $backupParent = Split-Path -Parent $backupFile
            New-Item -ItemType Directory -Path $backupParent -Force | Out-Null
            if (-not (Test-Path -LiteralPath $backupFile)) {
                Copy-Item -LiteralPath $destination -Destination $backupFile -Force
            }
        }
        Copy-Item -LiteralPath $srcFile.FullName -Destination $destination -Force
    }
    if (-not (Test-Path -LiteralPath $exePath -PathType Leaf)) { Stop-Script "lichii.exe is missing after extraction: $exePath" }
    $filesToInstall | Where-Object { $_.Extension -in @('.exe','.dll') } | Unblock-File -ErrorAction SilentlyContinue

    $vcRedist = Get-ChildItem -LiteralPath $sourceRoot -Filter 'vc_redist.x64.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($vcRedist) {
        Write-Log 'Microsoft Visual C++ x64 runtime found in the archive; installing/updating silently.'
        $vcProc = Start-Process -FilePath $vcRedist.FullName -ArgumentList '/install','/quiet','/norestart' -Verb RunAs -Wait -PassThru
        if ($vcProc.ExitCode -in @(0,3010,1638)) { Write-Log "Visual C++ runtime ready (exit code $($vcProc.ExitCode))." 'OK' }
        else { Write-Log "Visual C++ runtime returned exit code $($vcProc.ExitCode)." 'WARN' }
    }
    Write-Change "Latest official Fritchii $AppVersion downloaded and all program files extracted to $InstallDir."
}
if (-not (Test-Path -LiteralPath $exePath -PathType Leaf)) {
    Stop-Script "Emulator executable not found: $exePath"
}
if ($needsBinaryUpdate -and -not $DryRun) {
    try {
        # Remove only obsolete files that the prior state says this installer
        # placed, and archive them first. This prevents removed DLLs from an old
        # build being left beside a newer build, without touching user data.
        if ($priorState -and $priorState.InstalledFiles) {
            $currentPackageFiles = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
            foreach ($relativePath in $installedFiles) { [void]$currentPackageFiles.Add(([string]$relativePath).Replace('/','\')) }
            $installRoot = [IO.Path]::GetFullPath($InstallDir).TrimEnd('\') + '\'
            foreach ($oldRelativePath in @($priorState.InstalledFiles)) {
                $relative = ([string]$oldRelativePath).Replace('/','\')
                if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|\\)\.\.(\\|$)') { continue }
                if ($currentPackageFiles.Contains($relative)) { continue }
                $oldPath = [IO.Path]::GetFullPath((Join-Path $InstallDir $relative))
                if (-not $oldPath.StartsWith($installRoot, [StringComparison]::OrdinalIgnoreCase)) { continue }
                if (-not (Test-Path -LiteralPath $oldPath -PathType Leaf)) { continue }
                $oldBackup = Join-Path $collisionBackup $relative
                $oldBackupFull = [IO.Path]::GetFullPath($oldBackup)
                if (-not $oldBackupFull.StartsWith(([IO.Path]::GetFullPath($collisionBackup).TrimEnd('\') + '\'), [StringComparison]::OrdinalIgnoreCase)) { continue }
                $oldBackupParent = Split-Path -Parent $oldBackupFull
                if (-not (Test-Path -LiteralPath $oldBackupParent)) { New-Item -ItemType Directory -Path $oldBackupParent -Force | Out-Null }
                if (-not (Test-Path -LiteralPath $oldBackupFull -PathType Leaf)) { Copy-Item -LiteralPath $oldPath -Destination $oldBackupFull -Force }
                Remove-Item -LiteralPath $oldPath -Force -ErrorAction Stop
                Write-Log "Removed obsolete, previously script-installed build file after backup: $relative" 'OK'
            }
        }
        $workRoot = [IO.Path]::GetFullPath($WorkDir).TrimEnd('\') + '\'
        $extractFull = [IO.Path]::GetFullPath($extractDir)
        if ($extractFull.StartsWith($workRoot, [StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $extractFull -PathType Container)) {
            Remove-Item -LiteralPath $extractFull -Recurse -Force
        }
        if (Test-Path -LiteralPath $zipPath -PathType Leaf) { Remove-Item -LiteralPath $zipPath -Force }
        Write-Log 'The installer verified ZIP and staging files were removed; emulator shader caches were preserved.' 'OK'
    } catch { Write-Log "Could not clean up all temporary installation files: $($_.Exception.Message)" 'WARN' }
}

# ===========================================================================
#  2. SHADER / PIPELINE CACHE
# ===========================================================================
Write-Log 'Shader and pipeline cache (managed by Fritchii)' 'STEP'
# Follow the installed build's release notes for shader preparation and
# vendor-specific cache behavior. Never overwrite these with stale assumptions.
if ($DryRun) {
    Write-Log 'Fritchii built-in shader preparation and disk cache are used; no undocumented preload switches are written.'
} else {
    Write-Log 'Existing nx2_switches.txt is left unchanged. Fritchii manages shader preparation and cache using its own features.' 'OK'
}
Write-Log 'Fritchii shader preparation: follow the current release notes and let any preparation finish before evaluating game startup.' 'INFO'
Write-Log 'GPU cache settings follow the installed Fritchii build documentation; no global cache or registry tweaks are applied.' 'OK'

# ===========================================================================
#  3. PER-GAME INI
# ===========================================================================
Write-Log 'Game settings' 'STEP'

$legacyManagedSettings = [ordered]@{
    'Renderer/backend'                          = '1'
    'Renderer/resolution_setup'                 = '3'
    'Renderer/scaling_filter'                   = '6'
    'Renderer/anti_aliasing'                    = '0'
    'Renderer/gpu_accuracy'                     = '0'
    'Renderer/nvdec_emulation'                  = '2'
    'Renderer/dyna_state'                       = '2'
    'Renderer/use_asynchronous_shaders'         = 'true'
    'Renderer/async_presentation'               = 'true'
    'Renderer/use_disk_shader_cache'            = 'true'
    'Renderer/use_vulkan_driver_pipeline_cache' = 'true'
    'System/use_docked_mode'                    = '1'
    'System/fast_cpu_time'                      = '0'
    'Cpu/cpu_accuracy'                          = '0'
    'Core/memory_layout_mode'                   = '2'
    'Core/use_multi_core'                       = 'true'
}
$expected = [ordered]@{ 'Renderer/nx2_frame_rate_limit' = '60' }

# Retire the older hard-coded profile once. Restore only values that still match
# the exact values this script forced, preserving anything the user changed later.
$iniMigrationDone = $priorState -and $priorState.PSObject.Properties['IniTunedDefaultsVersion'] -and ([int]$priorState.IniTunedDefaultsVersion -ge 2)
if ($priorState -and -not $iniMigrationDone -and (Test-Path -LiteralPath $GameIni -PathType Leaf)) {
    $backupIni = $null
    if ($priorState -and $priorState.BackupDir) { $backupIni = Join-Path ([string]$priorState.BackupDir) "$TitleId.ini" }
    $backupValues = @{}
    if ($backupIni -and (Test-Path -LiteralPath $backupIni -PathType Leaf)) {
        $backupSection = ''
        foreach ($line in (Get-Content -LiteralPath $backupIni)) {
            if ($line -match '^\s*\[([^\]]+)\]\s*$') { $backupSection = $Matches[1]; continue }
            if ($line -match '^\s*([^;=#]+?)\s*=\s*(.*?)\s*$') { $backupValues["$backupSection/$($Matches[1].Trim())"] = $Matches[2].Trim() }
        }
    }
    $iniLines = New-Object System.Collections.Generic.List[string]
    (Get-Content -LiteralPath $GameIni) | ForEach-Object { $iniLines.Add([string]$_) }
    $sectionNow = ''
    $removeLines = New-Object System.Collections.Generic.HashSet[int]
    for ($lineNumber = 0; $lineNumber -lt $iniLines.Count; $lineNumber++) {
        if ($iniLines[$lineNumber] -match '^\s*\[([^\]]+)\]\s*$') { $sectionNow = $Matches[1]; continue }
        if ($iniLines[$lineNumber] -notmatch '^\s*([^;=#]+?)\s*=\s*(.*?)\s*$') { continue }
        $keyName = $Matches[1].Trim()
        $keyValue = $Matches[2].Trim()
        $keyPath = "$sectionNow/$keyName"
        if (-not $legacyManagedSettings.Contains($keyPath) -or $keyValue -ne $legacyManagedSettings[$keyPath]) { continue }
        $sectionStart = $lineNumber
        for ($back = $lineNumber - 1; $back -ge 0; $back--) {
            if ($iniLines[$back] -match '^\s*\[([^\]]+)\]\s*$') { $sectionStart = $back; break }
        }
        $sectionEnd = $iniLines.Count
        for ($forward = $lineNumber + 1; $forward -lt $iniLines.Count; $forward++) {
            if ($iniLines[$forward] -match '^\s*\[([^\]]+)\]\s*$') { $sectionEnd = $forward; break }
        }
        $hasManagedMarkers = $false
        $hasDefaultMarker = $false
        $hasGlobalMarker = $false
        for ($markerIndex = $sectionStart + 1; $markerIndex -lt $sectionEnd; $markerIndex++) {
            if ($iniLines[$markerIndex] -match ('^\s*' + [regex]::Escape("$keyName\default") + '\s*=\s*false\s*$')) { $hasDefaultMarker = $true }
            if ($iniLines[$markerIndex] -match ('^\s*' + [regex]::Escape("$keyName\use_global") + '\s*=\s*false\s*$')) { $hasGlobalMarker = $true }
        }
        $hasManagedMarkers = $hasDefaultMarker -and $hasGlobalMarker
        if (-not $hasManagedMarkers) { continue }
        if ($backupValues.ContainsKey($keyPath)) { $iniLines[$lineNumber] = "$keyName=$($backupValues[$keyPath])" }
        else { [void]$removeLines.Add($lineNumber) }
        foreach ($suffix in @('default','use_global')) {
            $metaName = "$keyName\$suffix"
            $restorePath = "$sectionNow/$metaName"
            for ($metaIndex = $sectionStart + 1; $metaIndex -lt $sectionEnd; $metaIndex++) {
                if ($iniLines[$metaIndex] -match ('^\s*' + [regex]::Escape($metaName) + '\s*=')) {
                    if ($backupValues.ContainsKey($restorePath)) { $iniLines[$metaIndex] = "$metaName=$($backupValues[$restorePath])" }
                    else { [void]$removeLines.Add($metaIndex) }
                }
            }
        }
    }
    if ($removeLines.Count -gt 0) {
        $keptLines = New-Object System.Collections.Generic.List[string]
        for ($i = 0; $i -lt $iniLines.Count; $i++) { if (-not $removeLines.Contains($i)) { $keptLines.Add($iniLines[$i]) } }
        $iniLines = $keptLines
    }
    if (-not $DryRun) {
        Set-Content -LiteralPath $GameIni -Value ($iniLines.ToArray()) -Encoding UTF8
        Write-Log 'Old script-managed emulator overrides were migrated; current Fritchii OoT defaults now apply.' 'OK'
    } else { Write-Log 'Would remove/restore old script-managed overrides and let current Fritchii OoT defaults apply.' }
}

$configAlreadyMatches = $false
if (Test-Path -LiteralPath $GameIni -PathType Leaf) {
    $configValues = @{}
    $configSection = ''
    foreach ($configLine in (Get-Content -LiteralPath $GameIni)) {
        if ($configLine -match '^\s*\[([^\]]+)\]\s*$') { $configSection = $Matches[1]; continue }
        if ($configLine -match '^\s*([^;=#]+?)\s*=\s*(.*?)\s*$') {
            $configValues["$configSection/$($Matches[1].Trim())"] = $Matches[2].Trim()
        }
    }
    $configAlreadyMatches = $true
    foreach ($keyPath in $expected.Keys) {
        if ($configValues[$keyPath] -ne $expected[$keyPath]) { $configAlreadyMatches = $false; break }
        $sectionName = ($keyPath -split '/',2)[0]
        $keyName = ($keyPath -split '/',2)[1]
        foreach ($suffix in @('default','use_global')) {
            if ($configValues["$sectionName/$keyName\$suffix"] -ne 'false') { $configAlreadyMatches = $false; break }
        }
        if (-not $configAlreadyMatches) { break }
    }
}

if ($DryRun) {
    if ($configAlreadyMatches) { Write-Log 'The 60 FPS limit is already correct; Fritchii controls the remaining OoT settings.' 'OK' }
    else {
        Write-Log "Would check/write the 60 FPS limit in $GameIni"
        foreach ($k in $expected.Keys) { Write-Log "Would set $k=$($expected[$k])" }
    }
} elseif ($configAlreadyMatches) {
    Write-Log 'The 60 FPS limit is correct; Fritchii-tuned OoT settings are left unchanged.' 'OK'
} else {
    New-Dir $EdenCustom
    if (Test-Path $GameIni) {
        New-Dir $BackupDir
        $configBackupPath = Join-Path $BackupDir "$TitleId.ini"
        if (-not (Test-Path -LiteralPath $configBackupPath)) {
            Copy-Item -LiteralPath $GameIni -Destination $configBackupPath -Force
        Write-Log "Original game INI backed up to $configBackupPath"
        }
    }
    # Enforce only the requested 60 FPS cap; let current Fritchii builds tune the rest.
    $merged = New-Object System.Collections.Generic.List[string]
    if (Test-Path -LiteralPath $GameIni) {
        (Get-Content -LiteralPath $GameIni) | ForEach-Object { $merged.Add([string]$_) }
    }
    $sectionsWithOverrides = @($expected.Keys | ForEach-Object { ($_ -split '/',2)[0] } | Select-Object -Unique)
    foreach ($sectionName in $sectionsWithOverrides) {
        $sectionHeader = "[$sectionName]"
        $startIndex = -1
        $endIndex = $merged.Count
        for ($idx = 0; $idx -lt $merged.Count; $idx++) {
            if ($merged[$idx].Trim() -ieq $sectionHeader) {
                $startIndex = $idx
                for ($scan = $idx + 1; $scan -lt $merged.Count; $scan++) {
                    if ($merged[$scan] -match '^\s*\[.+\]\s*$') { $endIndex = $scan; break }
                }
                break
            }
        }
        if ($startIndex -lt 0) {
            if ($merged.Count -gt 0 -and $merged[$merged.Count - 1] -ne '') { $merged.Add('') }
            $merged.Add($sectionHeader)
            $startIndex = $merged.Count - 1
            $endIndex = $merged.Count
        }

        $sectionKeys = @($expected.Keys | Where-Object { $_.StartsWith("$sectionName/") })
        foreach ($keyPath in $sectionKeys) {
            $keyName = $keyPath.Substring($sectionName.Length + 1)
            $value = $expected[$keyPath]
            $foundLine = -1
            for ($idx = $startIndex + 1; $idx -lt $endIndex; $idx++) {
                if ($merged[$idx] -match ('^\s*' + [regex]::Escape($keyName) + '\s*=')) {
                    $foundLine = $idx
                    break
                }
            }
            if ($foundLine -ge 0) {
                $merged[$foundLine] = "$keyName=$value"
            } else {
                $merged.Insert($endIndex, "$keyName=$value")
                $endIndex++
            }
            foreach ($suffix in @('default','use_global')) {
                $metaName = "$keyName\$suffix"
                $metaLine = -1
                for ($idx = $startIndex + 1; $idx -lt $endIndex; $idx++) {
                    if ($merged[$idx] -match ('^\s*' + [regex]::Escape($metaName) + '\s*=')) {
                        $metaLine = $idx
                        break
                    }
                }
                if ($metaLine -ge 0) { $merged[$metaLine] = "$metaName=false" }
                else { $merged.Insert($endIndex, "$metaName=false"); $endIndex++ }
            }
        }
    }
    Set-Content -LiteralPath $GameIni -Value ($merged.ToArray()) -Encoding UTF8
    Write-Change "Merged the 60 FPS limit into $GameIni; all other Fritchii OoT settings were preserved."

    $lines   = Get-Content -LiteralPath $GameIni
    $section = ''
    $read    = @{}
    foreach ($l in $lines) {
        if ($l -match '^\s*\[([^\]]+)\]\s*$') { $section = $Matches[1]; continue }
        if ($l -match '^\s*([^;=#]+?)\s*=\s*(.*?)\s*$') { $read["$section/$($Matches[1].Trim())"] = $Matches[2].Trim() }
    }
    $bad = 0
    foreach ($k in $expected.Keys) {
        if ($read[$k] -ne $expected[$k]) {
            Write-Log "Verification: $k = '$($read[$k])', expected '$($expected[$k])'" 'ERROR'; $bad++
        }
    }
    if ($bad -eq 0) { Write-Log 'Verified: the 60 FPS limit has the correct value.' 'OK' }
    else { Stop-Script "$bad keys could not be verified." }
}

# ===========================================================================
#  4. NVIDIA / GPU DRIVER
# ===========================================================================
Write-Log 'GPU driver' 'STEP'
if ($nvidia) {
    Write-Log 'NVIDIA GPU detected. The current Fritchii build manages its documented shader cache and GPU features; obsolete NPI overrides are avoided.' 'OK'
} else {
Write-Log 'Non-NVIDIA GPU detected. Vulkan and Fritchii built-in shader preparation will be used.' 'OK'
}

# ===========================================================================
#  5. WINDOWS 11 - SAFE SETTINGS, PER-APP GPU SELECTION
# ===========================================================================
Write-Log 'Windows 11 settings' 'STEP'
$highPerformanceScheme = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
$balancedPowerScheme = '381b4222-f694-41f0-9685-ff5bb260df2e'
$powerCfg = Join-Path $env:windir 'System32\powercfg.exe'
$currentPowerScheme = Get-ActivePowerSchemeGuid
if (-not $currentPowerScheme) { Stop-Script 'Could not read the currently active Windows power plan; refusing to replace a plan that cannot be restored later.' }
$originalPowerSchemeGuid = if ($priorState -and $priorState.PSObject.Properties['OriginalPowerSchemeGuid'] -and $priorState.OriginalPowerSchemeGuid) { [string]$priorState.OriginalPowerSchemeGuid } else { $currentPowerScheme }
$managedPowerSchemeGuid = if ($priorState -and $priorState.PSObject.Properties['ManagedPowerSchemeGuid']) { [string]$priorState.ManagedPowerSchemeGuid } else { $null }
$availableSchemes = @(& $powerCfg /list 2>$null)
$schemeListText = $availableSchemes -join "`n"
$managedPlanExists = $managedPowerSchemeGuid -and ($schemeListText -match [regex]::Escape($managedPowerSchemeGuid))
$createdManagedPlan = $false
$basePowerScheme = if ($schemeListText -match [regex]::Escape($highPerformanceScheme)) { $highPerformanceScheme } else { $balancedPowerScheme }
$processorGroup = '54533251-82be-4824-96c1-47b60b740d00'
$boostSetting = 'be337238-0d82-4146-a960-4f3749d470c7'
$coolingSetting = '94d3a615-a899-4ac5-ae2b-e4d8f634367f'
$minProcessorSetting = '893dee8e-2bef-41e0-89c6-b55d0929964c'
$maxProcessorSetting = 'bc5038f7-23e0-4960-96da-33abaf5935ec'
if ($DryRun) {
    if ($managedPlanExists) { Write-Log "Would configure and permanently activate existing Fritchii maximum performance plan: $managedPowerSchemeGuid" }
    else { Write-Log "Would create a permanent Fritchii maximum performance plan based on $basePowerScheme, configure maximum CPU boost, and activate it." }
    Write-Log 'The plan remains active after Fritchii closes. Use -Revert to restore the saved original plan and remove the Fritchii plan.'
} else {
    if (-not $managedPlanExists) {
        $duplicateOutput = @(& $powerCfg /duplicatescheme $basePowerScheme 2>$null)
        if ($LASTEXITCODE -ne 0 -or ($duplicateOutput -join ' ') -notmatch '(?i)([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})') {
            Stop-Script 'Could not create the permanent Fritchii maximum performance power plan. Power settings were not changed.'
        }
        $managedPowerSchemeGuid = $Matches[1].ToLowerInvariant()
        $createdManagedPlan = $true
        & $powerCfg /changename $managedPowerSchemeGuid 'Fritchii Maximum Performance' 'Permanent maximum processor boost plan managed by the Fritchii setup script.' 2>$null | Out-Null
    }
    $powerSettingsApplied = $true
    foreach ($setting in @(
        [pscustomobject]@{ Guid=$boostSetting; Value=2; Label='Aggressive maximum CPU boost' }
        [pscustomobject]@{ Guid=$coolingSetting; Value=1; Label='Active cooling policy' }
        [pscustomobject]@{ Guid=$minProcessorSetting; Value=100; Label='100% minimum processor state' }
        [pscustomobject]@{ Guid=$maxProcessorSetting; Value=100; Label='100% maximum processor state' }
    )) {
        & $powerCfg /setacvalueindex $managedPowerSchemeGuid $processorGroup $setting.Guid $setting.Value 2>$null | Out-Null
        $acSet = ($LASTEXITCODE -eq 0)
        & $powerCfg /setdcvalueindex $managedPowerSchemeGuid $processorGroup $setting.Guid $setting.Value 2>$null | Out-Null
        $dcSet = ($LASTEXITCODE -eq 0)
        if (-not $acSet -or -not $dcSet) { $powerSettingsApplied = $false; Write-Log "Could not set $($setting.Label) for both AC and battery operation." 'WARN' }
    }
    if (-not $powerSettingsApplied) {
        if ($createdManagedPlan) { & $powerCfg /delete $managedPowerSchemeGuid 2>$null | Out-Null }
        Stop-Script 'Windows did not accept all maximum performance power settings. The power plan was not activated.'
    }
    & $powerCfg /setactive $managedPowerSchemeGuid 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        if ($createdManagedPlan) { & $powerCfg /delete $managedPowerSchemeGuid 2>$null | Out-Null }
        Stop-Script 'Could not activate the permanent Fritchii maximum performance power plan.'
    }
    if ($priorState) {
        $priorState | Add-Member -NotePropertyName OriginalPowerSchemeGuid -NotePropertyValue $originalPowerSchemeGuid -Force
        $priorState | Add-Member -NotePropertyName ManagedPowerSchemeGuid -NotePropertyValue $managedPowerSchemeGuid -Force
        $stateSeed = $priorState
    } else {
        $stateSeed = [ordered]@{ OriginalPowerSchemeGuid=$originalPowerSchemeGuid; ManagedPowerSchemeGuid=$managedPowerSchemeGuid }
    }
    $stateSeed | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $StateFile -Encoding UTF8
    Write-Change "Permanent Fritchii maximum performance power plan configured and activated: $managedPowerSchemeGuid. It stays active after the emulator closes."
}
$gameBarKey = 'HKCU:\Software\Microsoft\GameBar'
$currentGameModeValue = $null
$currentGameModeExists = $false
try {
    $currentGameModeValue = (Get-ItemProperty -Path $gameBarKey -Name 'AutoGameModeEnabled' -ErrorAction Stop).AutoGameModeEnabled
    $currentGameModeExists = $true
} catch {}
$oldGameModeValue = $currentGameModeValue
$oldGameModeExists = $currentGameModeExists
if ($priorState -and $priorState.PSObject.Properties['OriginalGameModeExisted']) {
    $oldGameModeExists = [bool]$priorState.OriginalGameModeExisted
    $oldGameModeValue = $priorState.OriginalGameModeValue
}
if ($DryRun) {
    if ([int]$currentGameModeValue -eq 1) { Write-Log 'Windows Game Mode is already enabled.' 'OK' }
    else { Write-Log 'Would enable Windows Game Mode for the current user profile.' }
} elseif ([int]$currentGameModeValue -eq 1) {
    Write-Log 'Windows Game Mode is already enabled.' 'OK'
} else {
    try {
        if (-not (Test-Path $gameBarKey)) { New-Item -Path $gameBarKey -Force | Out-Null }
        New-ItemProperty -Path $gameBarKey -Name 'AutoGameModeEnabled' -Value 1 -PropertyType DWord -Force | Out-Null
        Write-Change 'Windows Game Mode enabled for the current user profile.'
    } catch { Write-Log "Could not enable Windows Game Mode: $($_.Exception.Message)" 'WARN' }
}
$gpuKey = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
$currentGpuPreference = $null
try { $currentGpuPreference = (Get-ItemProperty -Path $gpuKey -Name $exePath -ErrorAction Stop).$exePath } catch {}
$oldGpuPreference = $currentGpuPreference
if ($priorState -and $priorState.PSObject.Properties['OriginalGpuPreference']) {
    $oldGpuPreference = $priorState.OriginalGpuPreference
}
if ($DryRun) {
    if ($currentGpuPreference -eq 'GpuPreference=2;') { Write-Log 'High performance GPU preference is already set.' 'OK' }
    else { Write-Log "Would select the High performance GPU for $exePath in the current Windows user profile." }
} elseif ($currentGpuPreference -eq 'GpuPreference=2;') {
    Write-Log 'High performance GPU preference is already set; registry is left unchanged.' 'OK'
} else {
    try {
        if (-not (Test-Path $gpuKey)) { New-Item -Path $gpuKey -Force | Out-Null }
        Set-ItemProperty -Path $gpuKey -Name $exePath -Value 'GpuPreference=2;' -Type String
        Write-Change 'Windows GPU preference set to High performance for lichii.exe (current user only).'
    } catch { Write-Log "Could not set the Windows GPU preference: $($_.Exception.Message)" 'WARN' }
}
Write-Log 'A permanent Fritchii maximum performance power plan is active. No global timer, Defender, or AppCompat tweaks are applied.'

# ===========================================================================
#  6. SHORTCUTS + STATE
# ===========================================================================
Write-Log 'Shortcuts' 'STEP'

$launcher = Join-Path $InstallDir 'Start Ocarina of Time.cmd'
$performanceLauncher = Join-Path $InstallDir 'Fritchii-Performance-Launcher.ps1'
$powerShellExe = Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe'
if ($DryRun) {
    Write-Log "Would create the game launcher: $launcher"
    Write-Log "Would create the Fritchii launcher: $performanceLauncher"
    Write-Log "Would create/update the Zelda shortcut using the game icon: $gameShortcutPath"
    Write-Log "Would create/update the Fritchii shortcut using the emulator icon: $emulatorShortcutPath"
} else {
    $gameShortcutExistedBefore = if ($priorState -and $priorState.PSObject.Properties['GameShortcutExistedBefore']) { [bool]$priorState.GameShortcutExistedBefore } else { $false }
    $gameShortcutBackup = if ($priorState -and $priorState.GameShortcutBackup) { [string]$priorState.GameShortcutBackup } else { $null }
    $emulatorShortcutExistedBefore = if ($priorState -and $priorState.PSObject.Properties['EmulatorShortcutExistedBefore']) { [bool]$priorState.EmulatorShortcutExistedBefore } else { $false }
    $emulatorShortcutBackup = if ($priorState -and $priorState.EmulatorShortcutBackup) { [string]$priorState.EmulatorShortcutBackup } else { $null }
    $profileConfigPath = Join-Path $InstallDir 'Fritchii-LaunchProfiles.json'
    $profileConfig = [ordered]@{ ExecutablePath=$exePath; GameFile=$GameFile } | ConvertTo-Json
    $currentProfileConfig = if (Test-Path -LiteralPath $profileConfigPath) { Get-Content -LiteralPath $profileConfigPath -Raw } else { '' }
    if ($currentProfileConfig.Trim() -cne $profileConfig.Trim()) {
        Set-Content -LiteralPath $profileConfigPath -Value $profileConfig -Encoding UTF8
        Write-Change 'Fritchii launch profile updated for the selected NUP file.'
    }
    $performanceLauncherContent = @'
param([ValidateSet('Game','Emulator')][string]$Mode)
$ErrorActionPreference = 'Stop'
$powerCfg = Join-Path $env:windir 'System32\powercfg.exe'
$profileFile = Join-Path $PSScriptRoot 'Fritchii-LaunchProfiles.json'
$profile = Get-Content -LiteralPath $profileFile -Raw | ConvertFrom-Json
$launchArguments = ''
if ($Mode -eq 'Game') { $launchArguments = '-f -g "' + [string]$profile.GameFile + '"' }
$startParameters = @{ FilePath=[string]$profile.ExecutablePath; WorkingDirectory=(Split-Path -Parent ([string]$profile.ExecutablePath)) }
if ($launchArguments) { $startParameters.ArgumentList = $launchArguments }
Start-Process @startParameters
exit 0
'@
    $currentLauncherContent = if (Test-Path -LiteralPath $performanceLauncher) { Get-Content -LiteralPath $performanceLauncher -Raw } else { '' }
    if ($currentLauncherContent.Trim() -cne $performanceLauncherContent.Trim()) {
        Set-Content -LiteralPath $performanceLauncher -Value $performanceLauncherContent -Encoding UTF8
        Write-Change 'Fritchii launcher created/updated; the permanent maximum performance power plan remains active.'
    }
    $gameShortcutArgs = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $performanceLauncher + '" -Mode Game'
    $emulatorShortcutArgs = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $performanceLauncher + '" -Mode Emulator'
    $cmdLines = @(
        '@echo off'
        ('"' + $powerShellExe + '" -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Fritchii-Performance-Launcher.ps1" -Mode Game')
        'exit /b %ERRORLEVEL%'
    )
    $launcherMatches = $false
    if (Test-Path -LiteralPath $launcher -PathType Leaf) {
        $existingLauncherLines = @(Get-Content -LiteralPath $launcher)
        $launcherMatches = ($existingLauncherLines.Count -eq $cmdLines.Count)
        if ($launcherMatches) {
            for ($lineIndex = 0; $lineIndex -lt $cmdLines.Count; $lineIndex++) {
                if ($existingLauncherLines[$lineIndex] -cne $cmdLines[$lineIndex]) { $launcherMatches = $false; break }
            }
        }
    }
    if ($launcherMatches) { Write-Log "Game launcher is already correct; leaving it unchanged: $launcher" 'OK' }
    else {
        Set-Content -LiteralPath $launcher -Value $cmdLines -Encoding OEM
        Write-Change "Game launcher created/updated: $launcher (launches the selected NUP directly)."
    }

    try {
        if ($desktopPath) {
            $gameShortcutNowExists = Test-Path -LiteralPath $gameShortcutPath
            if (-not $priorState -or -not $priorState.PSObject.Properties['GameShortcutExistedBefore']) {
                $gameShortcutExistedBefore = $gameShortcutNowExists
            }
            $gameIcon = Join-Path $EdenRoot 'icons\eden-0400486024DEC000.ico'
            if (-not (Test-Path -LiteralPath $gameIcon -PathType Leaf)) { $gameIcon = "$exePath,0" }
            $sc = (New-Object -ComObject WScript.Shell).CreateShortcut($gameShortcutPath)
            $existingGameIcon = ([string]$sc.IconLocation) -replace ',0$',''
            $gameShortcutCorrect = $gameShortcutNowExists -and ($sc.TargetPath -ieq $powerShellExe) -and
                ($sc.Arguments -ceq $gameShortcutArgs) -and ($sc.WorkingDirectory -ieq $InstallDir) -and
                ($existingGameIcon -ieq ($gameIcon -replace ',0$',''))
            if ($gameShortcutCorrect) {
                Write-Log 'Zelda desktop shortcut is already correct; leaving it unchanged.' 'OK'
            } else {
                if ($gameShortcutNowExists -and $gameShortcutExistedBefore -and -not $gameShortcutBackup) {
                    New-Dir $BackupDir
                    $gameShortcutBackup = Join-Path $BackupDir 'The Legend of Zelda Ocarina of Time.lnk'
                    Copy-Item -LiteralPath $gameShortcutPath -Destination $gameShortcutBackup -Force
                }
                if ($gameIcon -eq "$exePath,0") { Write-Log 'Zelda icon is unavailable; using the Fritchii icon as a fallback.' 'WARN' }
                $sc.TargetPath       = $powerShellExe
                $sc.Arguments        = $gameShortcutArgs
                $sc.WorkingDirectory = $InstallDir
                $sc.IconLocation     = $gameIcon
                $sc.Save()
                Write-Change 'Zelda desktop shortcut created/updated with the OoT folder NUP file and the game emulator icon.'
            }

            $emulatorShortcutNowExists = Test-Path -LiteralPath $emulatorShortcutPath
            if (-not $priorState -or -not $priorState.PSObject.Properties['EmulatorShortcutExistedBefore']) {
                $emulatorShortcutExistedBefore = $emulatorShortcutNowExists
            }
            if ($emulatorShortcutNowExists -and $emulatorShortcutExistedBefore -and -not $emulatorShortcutBackup) {
                New-Dir $BackupDir
                $emulatorShortcutBackup = Join-Path $BackupDir 'Fritchii.lnk'
                Copy-Item -LiteralPath $emulatorShortcutPath -Destination $emulatorShortcutBackup -Force
            }
            $emulatorShortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($emulatorShortcutPath)
            $emulatorShortcutCorrect = $emulatorShortcutNowExists -and ($emulatorShortcut.TargetPath -ieq $powerShellExe) -and
                ($emulatorShortcut.Arguments -ceq $emulatorShortcutArgs) -and
                ($emulatorShortcut.WorkingDirectory -ieq $InstallDir) -and ($emulatorShortcut.IconLocation -ieq "$exePath,0")
            if ($emulatorShortcutCorrect) {
                Write-Log 'Fritchii desktop shortcut is already correct; leaving it unchanged.' 'OK'
            } else {
                if ($emulatorShortcutNowExists -and $emulatorShortcutExistedBefore -and -not $emulatorShortcutBackup) {
                    New-Dir $BackupDir
                    $emulatorShortcutBackup = Join-Path $BackupDir 'Fritchii.lnk'
                    Copy-Item -LiteralPath $emulatorShortcutPath -Destination $emulatorShortcutBackup -Force
                }
                $emulatorShortcut.TargetPath = $powerShellExe
                $emulatorShortcut.Arguments = $emulatorShortcutArgs
                $emulatorShortcut.WorkingDirectory = $InstallDir
                $emulatorShortcut.IconLocation = "$exePath,0"
                $emulatorShortcut.Save()
                Write-Change 'Fritchii shortcut created/updated on the desktop using the emulator icon.'
            }
        }
    } catch { Write-Log 'Could not create a desktop shortcut.' 'WARN' }

    $state = [ordered]@{
        InstalledAt       = (Get-Date).ToString('s')
        InstallDir        = $InstallDir
        Version           = $AppVersion
        AppAssetBytes     = $AppZipBytes
        AppAssetSha256    = $AppZipSha256
        BackupDir         = $(if (Test-Path $BackupDir) { $BackupDir } else { $null })
        OriginalGpuPreference = $oldGpuPreference
        OriginalPowerSchemeGuid = $originalPowerSchemeGuid
        ManagedPowerSchemeGuid = $managedPowerSchemeGuid
        OriginalGameModeExisted = $oldGameModeExists
        OriginalGameModeValue = $oldGameModeValue
        IniTunedDefaultsVersion = 2
        GameIni           = $GameIni
        GameFile          = $GameFile
        InstalledFiles    = $(if ($needsBinaryUpdate) { $installedFiles } else { @($priorState.InstalledFiles) })
        SwitchFileExistedBefore = $switchFileExistedBefore
        GameShortcutExistedBefore = $gameShortcutExistedBefore
        GameShortcutBackup = $gameShortcutBackup
        EmulatorShortcutExistedBefore = $emulatorShortcutExistedBefore
        EmulatorShortcutBackup = $emulatorShortcutBackup
    }
    $state | ConvertTo-Json | Set-Content -LiteralPath $StateFile -Encoding UTF8
}

# ===========================================================================
#  REPORT
# ===========================================================================
$reportLines = @(
    'FRITCHII SETUP REPORT  __DATE__'
    '================================================================'
    'Emulator : Fritchii __VER__ (Windows x64); latest published release with an official Windows x64 ZIP from the GitHub Releases API'
    'Install   : __DIR__'
    'Title     : The Legend of Zelda: Ocarina of Time, Title ID 0400486024DEC000'
    'Game file : __GAMEFILE__ (NUP container used directly; not extracted separately)'
    ''
    'OOT PERFORMANCE SETTINGS (latest installed Fritchii version)'
    '----------------------------------------------------------------'
    'The installed Fritchii build controls its version-specific OoT renderer, CPU, memory, async, and cache defaults.'
    'The online scan above shows the current official version and release notes; the script does not overwrite build tuning.'
    'The per-game nx2_frame_rate_limit=60 setting is retained for the 60 FPS target.'
    'Let the emulator shader/pipeline preparation finish when requested by the current build; release notes may require preparation after an update.'
    'Do not routinely clear shader/pipeline caches; the emulator and driver handle version changes as described in release notes.'
    'Shader/pipeline cache files are retained across game restarts and save-file resets so previously prepared shaders can be reused.'
    'The script does not delete game saves; start a new playthrough using the game own reset/new-game controls.'
    'Use Fritchii Performance Overlay (if available in the current build) and Help > Export Log to investigate remaining frame-time spikes.'
    ''
    'GPU DRIVER'
    '----------------------------------------------------------------'
    'GPU cache and GPU thread features follow the current Fritchii build documentation.'
    'Existing nx2_switches.txt is left unchanged; no undocumented switches are forced.'
    'No forced NVIDIA Profile Inspector override is applied.'
    ''
    'WINDOWS'
    '----------------------------------------------------------------'
    'High performance GPU preference for lichii.exe in the current user profile.'
    'Windows Game Mode enabled for the current user profile (saved for Revert).'
    'A permanent Fritchii maximum performance power plan is active, with aggressive boost and 100% minimum and maximum processor states on AC and battery.'
    'CachyOS BORE/sched-ext are Linux kernel features; WSL2 cannot control Windows lichii.exe threads.'
    'Built-in scheduler/GPU thread handling follows the current Fritchii build; duplicate CPU affinity/timer hacks are skipped.'
    'A Zelda shortcut using the emulator existing OoT icon and selected NUP file was created on the desktop.'
    'A Fritchii shortcut targeting lichii.exe was created on the desktop to launch the emulator directly.'
    'No global timer, Defender, or AppCompat tweaks; the Fritchii maximum performance power plan is the only power-plan change.'
    'Windows                  Game Mode + Fritchii GPU preference + permanent maximum performance power plan.'
    'Windows cleanup           Each launch: old (14+ days) files in the current user Temp folder; locked files are skipped.'
    'RAM cleanup               Do not run RAM/standby-list cleaners; retain Windows memory management.'
    'Disk cleanup              Targeted Temp cleanup; no broad removal of Downloads, Recycle Bin, or Windows Update data.'
    'Game/driver caches        Shader, pipeline, DirectX, and GPU driver caches are preserved.'
    'Online scan                Each launch: Microsoft, Fritchii, NVIDIA/AMD/Intel, OoT emulators, broad gaming tests/community.'
    'Search report              __ONLINE_REPORT__'
    'Pipeline cache             Not cleared after every build; Fritchii prepares its local cache itself.'
    ''
    'HOW TO REVERT'
    '----------------------------------------------------------------'
    'Run:  __SCRIPT__ -Revert'
    'This restores configuration + GPU preference + Game Mode + the original power plan, and removes the script-managed Fritchii plan.'
    ''
    'IMPORTANT ABOUT THE GAME FILE'
    '----------------------------------------------------------------'
    '1. The game file must be a valid .nup container that you own.'
    '2. NUP is not a regular ZIP; the emulator NUP reader reads the file directly.'
    '3. If multiple NUP versions exist, the highest version number is selected by default.'
    '4. Let Fritchii Preparing shaders finish before judging performance.'
    '5. Each run automatically searches for new NUP versions in Spel and updates the emulator game shortcut to the newest matching OoT file.'
    '6. New Fritchii builds are downloaded only from official Windows x64 assets; builds that change file format, executable name, or requirements must retain a compatible upstream Windows release format.'
    ''
    'Log: __LOG__'
)
$report = ($reportLines -join $NL).Replace('__DATE__', (Get-Date -Format 'yyyy-MM-dd HH:mm')).
    Replace('__VER__', $AppVersion).Replace('__DIR__', $InstallDir).
    Replace('__EDEN__', $EdenRoot).Replace('__LOG__', $LogFile).Replace('__GAMEFILE__', $GameFile).
    Replace('__SCRIPT__', (Split-Path -Leaf $env:FRITCHII_SELF)).
    Replace('__ONLINE_REPORT__', $OnlineReport)

if (-not $DryRun) { Set-Content -LiteralPath $ReportFile -Value $report -Encoding UTF8 }

# Launch the selected NUP directly. Fritchii/Lichii supports -g for a NUP path.
if ($DryRun) {
    Write-Log "Would launch: `"$exePath`" -g `"$GameFile`""
} else {
    try {
        $gameProcess = Start-Process -FilePath $exePath -ArgumentList @('-f', '-g', "`"$GameFile`"") -WorkingDirectory $InstallDir -PassThru
        Write-Change "Fritchii launched with game: $GameFile (PID $($gameProcess.Id))."
    } catch {
        Stop-Script "Could not launch the game using -g: $($_.Exception.Message)"
    }
}

# ===========================================================================
#  SUMMARY
# ===========================================================================
Write-Host ''
Write-Host '==================================================================' -ForegroundColor White
if ($DryRun) {
    Write-Host '  DRY RUN complete - no changes made.' -ForegroundColor Yellow
} else {
    Write-Host "  COMPLETE. $($script:Changes.Count) changes applied." -ForegroundColor Green
    Write-Host "  Report: $ReportFile"
    Write-Host "  Log:    $LogFile"
}
if ($script:Warnings.Count -gt 0) {
    Write-Host ''
    Write-Host "  $($script:Warnings.Count) warning(s):" -ForegroundColor Yellow
    $script:Warnings | ForEach-Object { Write-Host "   - $_" -ForegroundColor Yellow }
}
Write-Host '==================================================================' -ForegroundColor White
Write-Host ''
Write-Host 'NEXT STEPS:' -ForegroundColor Cyan
Write-Host '  1. The script loads the NUP file directly; it must be a valid dump.'
Write-Host '  2. Allow Fritchii built-in shader preparation to finish after a new installation or driver change.'
Write-Host '  3. For future launches, use Start Ocarina of Time.cmd.'
Write-Host '  4. 60 FPS is the target. No installer can guarantee 60 FPS on every Windows 11 PC.'
Write-Host ''
Write-Host 'Launch the game using "Start Ocarina of Time.cmd" in the emulator folder.' -ForegroundColor Green
Write-Host ''
#PSEND
